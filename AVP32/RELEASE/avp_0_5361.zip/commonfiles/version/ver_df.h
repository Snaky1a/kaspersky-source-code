////////////////////////////////////////////////////////////////////
//
//  VER_DF.H
//  DataFellows Version definitions specific
//  Project AVP
//  Alexey de Mont de Rique [graf@avp.ru], Kaspersky Labs. 1999
//  Copyright (c) Kaspersky Labs.
//
////////////////////////////////////////////////////////////////////

#ifndef __VER_DF_H
#define __VER_DF_H

/*
#define BUILD_YEAR      2001
#define BUILD_WEEK        18
#define BUILD_DAILYBUILD   0
#define BUILD (BUILD_YEAR-1998)*1000+(10*BUILD_WEEK)+BUILD_DAILYBUILD
*/

#ifndef VER_FILEVERSION_COMPILATION
#define VER_FILEVERSION_COMPILATION 5361
#endif

#endif//__VER_DF_H

