////////////////////////////////////////////////////////////////////
//
//  SQ_U.CPP
//  Unpack proc for squish
//  General purpose
//  Alexey de Mont de Rique [graf@avp.ru], Kaspersky Labs. 1999
//  Copyright (c) Kaspersky Labs.
//
////////////////////////////////////////////////////////////////////
#include "stdafx.h"

#if (defined(__WATCOMC__) && (defined(__DOS__)||defined(__OS2__)))
 #define NOAFX
 #include <os2.h>
 #include "../typedef.h"
 #include <tchar.h>
 #define AFXAPI
 #include "_carray.h"

 #include "../../avp32/retcode3.h"
 #include "../scanApi/avp_msg.h"
#endif

struct s_data{
	BYTE* s_fp;
	BYTE* o_ptr;
	void* yield;
	WORD  s_buf;
	BYTE  s_count;
	int   y_count;
};

void fillbitbuf(s_data& sd)
{
#if defined (MACHINE_IS_BIG_ENDIAN)
	sd.s_buf=(WORD)((unsigned char)sd.s_fp[0]+(((unsigned char)sd.s_fp[1])<<8));
#else
	sd.s_buf=*((WORD*)sd.s_fp);
#endif	
	sd.s_fp+=2;
	sd.s_count= 0x10;
	
	if(sd.yield && sd.y_count-- < 0){
		sd.y_count=4;
		((void (*)())sd.yield)();
	}
}


#define getbit( b )\
{\
	b = sd.s_buf & 1;\
	if(--sd.s_count) sd.s_buf >>= 1;\
	else fillbitbuf(sd);\
}\

#define getbyte() (*(sd.s_fp++))


#if ((defined(__WATCOMC__) && (defined(__DOS__)||defined(__OS2__)))||defined(__unix__))
void init(s_data& sd)
#else
static void init(s_data& sd)
#endif
{
#if defined (MACHINE_IS_BIG_ENDIAN)
	sd.s_buf=(WORD)((unsigned char)sd.s_fp[0]+(((unsigned char)sd.s_fp[1])<<8));
#else
	sd.s_buf=*((WORD*)sd.s_fp);
#endif	
	sd.s_fp+=2;
	sd.s_count=0x10;
}

static int process(s_data& sd){
    DWORD len;
    DWORD bit;
    short int span;
	while(1){
		getbit(bit);
        if(bit) {
			*sd.o_ptr++=getbyte();
			continue;
        }
		getbit(bit);
        if(!bit) {
			getbit(len);
			len<<=1;
			getbit(bit);
			len |= bit;
			len += 2;
			span=getbyte() | 0xff00;
        } else {
			span=getbyte();
			len=getbyte();
			span |= ((len & ~0x07)<<5) | 0xe000;
			len = (len & 0x07)+2;
			if (len==2) {
				len=getbyte();
				if(len==0)      return 0;// end mark of compreesed load module
				if(len==1)      continue;// segment change
				else            len++;
			}
        }
        for( ;len>0;len--,sd.o_ptr++)      *sd.o_ptr=*(sd.o_ptr+span);
	}
	return 1;
}

DWORD unsqu (BYTE *i_buf,BYTE *o_buf)
{
	s_data sd;
	memset(&sd,0,sizeof(sd));
    sd.o_ptr=o_buf;
    sd.s_fp=i_buf;
    init(sd);
    process(sd);
    return(sd.o_ptr-o_buf);
}

DWORD unsqu_y (BYTE *i_buf,BYTE *o_buf, void* yield_)
{
	s_data sd;
	memset(&sd,0,sizeof(sd));
	sd.yield=yield_;
    sd.o_ptr=o_buf;
    sd.s_fp=i_buf;
    init(sd);
    process(sd);
    return(sd.o_ptr-o_buf);
}
