#include <WINDOWS.H>
#include <winioctl.h>
#include <_avpio.h>
#include "../Avp_iocl.h"
