#define FN_DISINFECT   0x00000001

//#define FN_UNPACK      0x00000002
//#define FN_EXTRACT     0x00000004
//#define FN_MAIL        0x00000008
//#define FN_CA          0x00000010

#define FN_UPDATES     0x00000020

#define FN_OPTIONS     0x00010000
#define FN_NETWORK     0x00020000

#define FN_FULL        0xFFFFFFFF
#define FN_MINIMAL     0x0000FFFF
